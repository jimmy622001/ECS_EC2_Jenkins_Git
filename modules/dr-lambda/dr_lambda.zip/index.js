exports.handler = async (event) => {
  const AWS = require('aws-sdk');
        
  // Testing mode
  const isTest = event.test_mode === true;
  const testDuration = event.test_duration_minutes || 60;
        
  // Set region to DR region
  AWS.config.update({region: process.env.DR_REGION});
        
  const ecs = new AWS.ECS();
  const autoscaling = new AWS.AutoScaling();
  const ec2 = new AWS.EC2();
        
  console.log('Disaster Recovery failover initiated', isTest ? "(TEST MODE)" : "");
        
  try {
    // 1. Scale up the ECS service
    console.log("Scaling up ECS service " + process.env.ECS_SERVICE + " in cluster " + process.env.ECS_CLUSTER);
    await ecs.updateService({
      cluster: process.env.ECS_CLUSTER,
      service: process.env.ECS_SERVICE,
      desiredCount: parseInt(process.env.DESIRED_CAPACITY)
    }).promise();
          
    // 2. Update the Auto Scaling Group for capacity and to use on-demand instances
    console.log("Updating ASG " + process.env.ASG_NAME + " to use on-demand instances");
    const asgParams = {
      AutoScalingGroupName: process.env.ASG_NAME,
      MinSize: parseInt(process.env.MIN_CAPACITY),
      MaxSize: parseInt(process.env.MAX_CAPACITY),
      DesiredCapacity: parseInt(process.env.DESIRED_CAPACITY),
      MixedInstancesPolicy: {
        // Switch to 100% on-demand instances during failover
        InstancesDistribution: {
          OnDemandBaseCapacity: parseInt(process.env.MIN_CAPACITY),
          OnDemandPercentageAboveBaseCapacity: 100
        }
      }
    };
          
    await autoscaling.updateAutoScalingGroup(asgParams).promise();
          
    console.log('DR environment successfully scaled up for failover');
          
    // If this is a test, schedule the cleanup after test duration
    if (isTest) {
      console.log("Test mode: Scheduling cleanup after " + testDuration + " minutes");
            
      // Create a CloudWatch Events rule to trigger cleanup after test duration
      const cloudwatchEvents = new AWS.CloudWatchEvents();
      const lambda = new AWS.Lambda();
            
      // Create a one-time rule that will trigger after test duration
      const ruleName = "dr-test-cleanup-" + Date.now();
      const scheduleExpression = "cron(" + new Date(Date.now() + testDuration * 60000).getUTCMinutes() + " " + new Date(Date.now() + testDuration * 60000).getUTCHours() + " " + new Date(Date.now() + testDuration * 60000).getUTCDate() + " " + (new Date(Date.now() + testDuration * 60000).getUTCMonth() + 1) + " ? " + new Date(Date.now() + testDuration * 60000).getUTCFullYear() + ")";
            
      await cloudwatchEvents.putRule({
        Name: ruleName,
        ScheduleExpression: scheduleExpression,
        State: 'ENABLED'
      }).promise();
            
      // Get the ARN of the cleanup Lambda function
      const lambdaParams = {
        FunctionName: process.env.AWS_LAMBDA_FUNCTION_NAME.replace('dr-scale-up', 'dr-test-cleanup')
      };
            
      const cleanupLambda = await lambda.getFunction(lambdaParams).promise();
            
      // Set the cleanup Lambda as the target for the rule
      await cloudwatchEvents.putTargets({
        Rule: ruleName,
        Targets: [
          {
            Id: 'CleanupTarget',
            Arn: cleanupLambda.Configuration.FunctionArn
          }
        ]
      }).promise();
            
      // Add permission for the rule to invoke the cleanup Lambda
      await lambda.addPermission({
        FunctionName: cleanupLambda.Configuration.FunctionName,
        StatementId: "AllowExecutionFromCloudWatch-" + Date.now(),
        Action: 'lambda:InvokeFunction',
        Principal: 'events.amazonaws.com',
        SourceArn: "arn:aws:events:" + process.env.DR_REGION + ":" + process.env.AWS_ACCOUNT_ID + ":rule/" + ruleName
      }).promise();
    }
          
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "DR failover completed successfully" + (isTest ? " (TEST MODE)" : ""),
        timestamp: new Date().toISOString()
      })
    };
  } catch (error) {
    console.error('Error during DR failover:', error);
    throw error;
  }
};
