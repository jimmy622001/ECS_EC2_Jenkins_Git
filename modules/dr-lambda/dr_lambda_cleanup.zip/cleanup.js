exports.handler = async (event) => {
  const AWS = require('aws-sdk');
        
  // Set region to DR region
  AWS.config.update({region: process.env.DR_REGION});
        
  const ecs = new AWS.ECS();
  const autoscaling = new AWS.AutoScaling();
        
  console.log('DR test cleanup initiated - restoring pilot light configuration');
        
  try {
    // 1. Scale down the ECS service to pilot light levels
    console.log("Scaling down ECS service " + process.env.ECS_SERVICE + " to pilot light levels");
    await ecs.updateService({
      cluster: process.env.ECS_CLUSTER,
      service: process.env.ECS_SERVICE,
      desiredCount: parseInt(process.env.PILOT_DESIRED_CAPACITY)
    }).promise();
          
    // 2. Update the Auto Scaling Group back to pilot light configuration with spot instances
    console.log("Updating ASG " + process.env.ASG_NAME + " back to pilot light configuration");
    const asgParams = {
      AutoScalingGroupName: process.env.ASG_NAME,
      MinSize: parseInt(process.env.PILOT_MIN_CAPACITY),
      MaxSize: parseInt(process.env.PILOT_MAX_CAPACITY),
      DesiredCapacity: parseInt(process.env.PILOT_DESIRED_CAPACITY),
      MixedInstancesPolicy: {
        // Switch back to mostly spot instances for cost efficiency
        InstancesDistribution: {
          OnDemandBaseCapacity: 0,
          OnDemandPercentageAboveBaseCapacity: 0  // Use 100% spot instances for pilot light
        }
      }
    };
          
    await autoscaling.updateAutoScalingGroup(asgParams).promise();
          
    console.log('DR environment successfully restored to pilot light configuration');
          
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'DR test cleanup completed successfully',
        timestamp: new Date().toISOString()
      })
    };
  } catch (error) {
    console.error('Error during DR test cleanup:', error);
    throw error;
  }
};
